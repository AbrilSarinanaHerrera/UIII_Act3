// ignore_for_file: public_member_api_docs, sort_constructors_first
class FloresModelo {
  final String nombre;
  final String posicion;
  final int aVista;
  final int totalVista;
  final String perfil;
  FloresModelo({
    required this.nombre,
    required this.posicion,
    required this.aVista,
    required this.totalVista,
    required this.perfil,
  });
}

final List<FloresModelo> cercanoFlores = [
  FloresModelo(
    nombre: "No.1",
    posicion: "Estos arreglos tienen 30% ",
    aVista: 0,
    totalVista: 0,
    perfil: "assets/6.jpg",
  ),
  FloresModelo(
    nombre: "No.2",
    posicion: "Estos arreglos tienen 30%",
    aVista: 0,
    totalVista: 0,
    perfil: "assets/9.jpg",
  ),
  FloresModelo(
    nombre: "No.3",
    posicion: "Estos arreglos tienen 30% ",
    aVista: 2,
    totalVista: 0,
    perfil: "assets/8.jpg",
  ),
];
