// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:flutter/material.dart';

class FloresN extends StatelessWidget {
  const FloresN({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    List<IconosF> customIcons = [
      IconosF(nombre: "Bodas", icono: 'assets/10.jpg'),
      IconosF(nombre: "VX's", icono: 'assets/2.jpg'),
      IconosF(nombre: "Cumpleaños", icono: 'assets/4.jpg'),
      IconosF(nombre: "Mas", icono: 'assets/more.png'),
    ];
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: List.generate(customIcons.length, (index) {
        return Column(
          children: [
            Container(
              width: 60,
              height: 60,
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: Theme.of(context)
                    .colorScheme
                    .primaryContainer
                    .withOpacity(0.4),
                shape: BoxShape.circle,
              ),
              child: Image.asset(
                customIcons[index].icono,
              ),
            ),
            const SizedBox(height: 6),
            Text(customIcons[index].nombre)
          ],
        );
      }),
    );
  }
}

class IconosF {
  final String nombre;
  final String icono;
  IconosF({
    required this.nombre,
    required this.icono,
  });
}
